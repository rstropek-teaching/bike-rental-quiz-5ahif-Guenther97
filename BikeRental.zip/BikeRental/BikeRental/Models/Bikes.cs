﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BikeRental.Models
{
    public class Bikes
    {
        public int ID { get; set; }
        public string Branch { get; set; }
        public string Notes { get; set; }
        public DateTime DateLastService { get; set; }
        public double RentalPriceFirstHour { get; set; }
        public double RentaulPriceAddHour { get; set; }
        public Categories BikeCategories { get; set; }
    }
}
