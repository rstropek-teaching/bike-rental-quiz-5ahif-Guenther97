﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BikeRental.Models
{
    public class Customers
    {
        public int ID { get; set; }
        public int Gender { get; set; }
        public string Firstname { get; set; }
        public string Lastname { get; set; }
        public DateTime Birthday { get; set; }
        public string Street { get; set; }
        public int Housenumber { get; set; }
        public int Zipcode { get; set; }
        public string Town { get; set; }
    }
}
