using BikeRental;
using BikeRental.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace BikeTest
{
    [TestClass]
    public class CostCalculationTest
    {
        [TestMethod]
        public void CostCalculationMethod()
        {
            Categories c = new Categories { CategoryName = "Standard Bike" };
            Bikes b = new Bikes { BikeCategories = c, Branch = "KTM", Notes = "Das ist ein cooles Bike", DateLastService = new DateTime(2016, 05, 27), RentalPriceFirstHour = 3.50, RentaulPriceAddHour = 5.00 };
            Customers cust = new Customers { Firstname = "Walter", Lastname = "Gruber", Birthday = new DateTime(1979, 02, 03), Gender = 0, Town = "Linz", Street = "Linzerstra�e", Housenumber = 82, Zipcode = 4200 };
            Rentals r = new Rentals { Customer = cust, bike = b, paid = false, RentalBegin = new DateTime(2018, 02, 14, 08, 15, 0), RentalEnd = new DateTime(2018, 02, 14, 10, 30, 0) };

            r.TotalCosts = CostCalculation.Calculation(r, b);

            Assert.IsTrue(r.TotalCosts == 13.50);

        }


        [TestMethod]
        public void CostCalculationMethod1()
        {
            Categories c = new Categories { CategoryName = "Trecking Bike" };
            Bikes b = new Bikes { BikeCategories = c, Branch = "KTM", Notes = "Das ist ein cooles Trecking Bike", DateLastService = new DateTime(2016, 05, 27), RentalPriceFirstHour = 5.00, RentaulPriceAddHour = 7.50 };
            Customers cust = new Customers { Firstname = "Walter", Lastname = "Gruber", Birthday = new DateTime(1979, 02, 03), Gender = 0, Town = "Linz", Street = "Linzerstra�e", Housenumber = 82, Zipcode = 4200 };
            Rentals r = new Rentals { Customer = cust, bike = b, paid = false, RentalBegin = new DateTime(2018, 02, 14, 08, 15, 0), RentalEnd = new DateTime(2018, 02, 14, 08, 25, 0) };

            r.TotalCosts = CostCalculation.Calculation(r, b);

            Assert.IsTrue(r.TotalCosts == 0.00);

        }


        [TestMethod]
        public void CostCalculationMethod2()
        {
            Categories c = new Categories { CategoryName = "Trecking Bike" };
            Bikes b = new Bikes { BikeCategories = c, Branch = "KTM", Notes = "Das ist ein cooles Trecking Bike", DateLastService = new DateTime(2016, 05, 27), RentalPriceFirstHour = 5.00, RentaulPriceAddHour = 7.50 };
            Customers cust = new Customers { Firstname = "Walter", Lastname = "Gruber", Birthday = new DateTime(1979, 02, 03), Gender = 0, Town = "Linz", Street = "Linzerstra�e", Housenumber = 82, Zipcode = 4200 };
            Rentals r = new Rentals { Customer = cust, bike = b, paid = false, RentalBegin = new DateTime(2018, 02, 14, 08, 15, 0), RentalEnd = new DateTime(2018, 02, 14, 08, 40, 0) };

            r.TotalCosts = CostCalculation.Calculation(r, b);

            Assert.IsTrue(r.TotalCosts == 5.00);

        }



    }
}
