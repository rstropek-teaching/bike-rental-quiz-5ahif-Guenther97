﻿using BikeRental.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BikeRental
{
    public class RentalContext : DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            //optionsBuilder.UseSqlServer("Server = (localdb)\\MSSQLLocalDB; Database = RentalDB; Trusted_Connection = True");
            optionsBuilder.UseSqlServer("Server = tcp:rentalbikeserver.database.windows.net,1433; Initial Catalog = BikeDB; Persist Security Info = False; User ID = ; Password =; MultipleActiveResultSets = False; Encrypt = True; TrustServerCertificate = False; Connection Timeout = 30;");
        }

        public DbSet<Customers> Customer { get; set; }
        public DbSet<Bikes> Bike { get; set; }
        public DbSet<Rentals> Rental { get; set; }

    }
}
