﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BikeRental.Models
{
    public class Rentals
    {
        public int ID { get; set; }
        public Customers Customer { get; set; }
        public Bikes bike { get; set; }
        public DateTime RentalBegin { get; set; }
        public DateTime RentalEnd { get; set; }
        public double TotalCosts { get; set; }
        public bool paid { get; set; }

    }
}
