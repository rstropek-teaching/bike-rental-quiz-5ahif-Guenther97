﻿using BikeRental.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BikeRental
{
    public class CostCalculation
    {

        public static double Calculation(Rentals r, Bikes b)
        {
            TimeSpan time = new TimeSpan ();
            time = r.RentalEnd - r.RentalBegin;
            double costs = 0.00;
            TimeSpan interval = TimeSpan.FromHours(1);

            if(time.Minutes < 15)
            {
                return costs;
            }

            if(time.Hours > 1)
            {
                costs = costs + b.RentalPriceFirstHour;
                time = time.Subtract(interval);
            }
            else if (time.Minutes > 15)
            {
                costs = costs + b.RentalPriceFirstHour;
                return costs;
            }

            while (time.Hours != 0)
            {
                costs = costs + b.RentaulPriceAddHour;
                time = time.Subtract(interval);
            }

            if(time.Hours == 0 && time.Minutes != 0)
            {
                costs = costs + b.RentaulPriceAddHour;
            }

            return costs;
        }

    }
}
