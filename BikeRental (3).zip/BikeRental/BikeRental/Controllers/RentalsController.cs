﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BikeRental.Models;
using Microsoft.AspNetCore.Mvc;

namespace BikeRental.Controllers
{
    [Route("api")]
    public class RentalsController : Controller
    {

        private readonly RentalContext rc = new RentalContext();

        List<Rentals> rentalList = new List<Rentals>();


        

        public RentalsController()
        {
            //cust.Add(new Customers { Firstname = "Walter", Lastname = "Gruber", Birthday = new DateTime(1979, 02, 03), Gender = 0, Town = "Linz", Street = "Linzerstraße", Housenumber = 82, Zipcode = 4200 });
            //cust.Add(new Customers { Firstname = "Herbert", Lastname = "Mayr", Birthday = new DateTime(1979, 02, 03), Gender = 0, Town = "Linz", Street = "Linzerstraße", Housenumber = 82, Zipcode = 4200 });
            //Customers c = new Customers { Firstname = "Herbert", Lastname = "Huber", Birthday = new DateTime(1979, 02, 03), Gender = 0, Town = "Linz", Street = "Linzerstraße", Housenumber = 82, Zipcode = 4200 };

            //Categories cat = new Categories { CategoryName = "Standard Bike" };
            //Bikes b = new Bikes { BikeCategories = cat, Branch = "KTM", Notes = "Das ist ein cooles Bike", DateLastService = new DateTime(2016, 05, 27), RentalPriceFirstHour = 3.50, RentaulPriceAddHour = 5.00 };
            ////Rentals r = new Rentals { Customer = c, bike = b, paid = false, RentalBegin = new DateTime(2018, 02, 14, 08, 15, 0), RentalEnd = new DateTime(2018, 02, 14, 10, 30, 0) };
            //Rentals r2 = new Rentals { Customer = c, bike = b, paid = false, RentalBegin = new DateTime(2017, 02, 14, 08, 15, 0), RentalEnd = new DateTime(2018, 02, 14, 10, 30, 0) };

            ////rc.Bike.Add(b);
            ////rc.Rental.Add(r);
            //r2.TotalCosts = CostCalculation.Calculation(r2, b);
            //rc.Rental.Add(r2);



            ////rc.Customer.Add(c);
            //rc.SaveChanges();
        }
        // GET api/customers
        [HttpGet]
        [Route("rentals")]
        public IActionResult Get()
        {
            
            List<Rentals> filterRental = new List<Rentals>();

            //for(int i=0; i<rc.Customer.Count(); i++)
            //{
            //    Customers c = new Customers();
            //    c = (Customers) rc.Customer.Where(f => f.Lastname == lastName);
            //    filterCust.Add(c);
            //}

                return Ok(rc.Rental);
            


            //for(int i=0; i<cust.Count; i++)
            //{
            //    if(cust[i].Lastname == lastName)
            //    {
            //        filterCust.Add(cust[i]);
            //    }
            //}

            //if(lastName != null)
            //{
            //    return Ok(filterCust);
            //}
            //else
            //{
            //    return Ok(cust);
            //}

        }



        // POST api/values
        [HttpPost]
        [Route("createRental")]
        public IActionResult Post([FromBody]Rentals rental)
        {

            rental.RentalBegin = DateTime.Now;


            rc.Rental.Add(rental);
            rc.SaveChanges();

            return Ok("Start a rental");
        }

        // PUT api/values/5
        [HttpPut]
        [Route("updateCustomer")]
        public IActionResult Put([FromQuery] int ID, [FromBody]Customers customer)
        {

            if (ID != customer.ID)
            {
                return BadRequest();
            }

            rc.Entry(customer).State = Microsoft.EntityFrameworkCore.EntityState.Modified;

            rc.SaveChanges();

            return Ok("Das Update wurde vollzogen");

        }

        // DELETE api/values/5
        [HttpDelete]
        [Route("deleteCustomer")]
        public IActionResult Delete([FromQuery] int ID)
        {
            var customer = rc.Customer.SingleOrDefault(c => c.ID == ID);

            rc.Customer.Remove(customer);

            rc.SaveChanges();

            return Ok(customer);
        }
    }
}
