﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BikeRental.Models;
using Microsoft.AspNetCore.Mvc;

namespace BikeRental.Controllers
{
    [Route("api")]
    public class BikesController : Controller
    {

        private readonly RentalContext rc = new RentalContext();

        List<Bikes> bikeList = new List<Bikes>();


        

        public BikesController()
        {
            //cust.Add(new Customers { Firstname = "Walter", Lastname = "Gruber", Birthday = new DateTime(1979, 02, 03), Gender = 0, Town = "Linz", Street = "Linzerstraße", Housenumber = 82, Zipcode = 4200 });
            //cust.Add(new Customers { Firstname = "Herbert", Lastname = "Mayr", Birthday = new DateTime(1979, 02, 03), Gender = 0, Town = "Linz", Street = "Linzerstraße", Housenumber = 82, Zipcode = 4200 });
            //Customers c = new Customers { Firstname = "Herbert", Lastname = "Huber", Birthday = new DateTime(1979, 02, 03), Gender = 0, Town = "Linz", Street = "Linzerstraße", Housenumber = 82, Zipcode = 4200 };

            //Categories cat = new Categories { CategoryName = "Standard Bike" };
            //Bikes b = new Bikes { BikeCategories = cat, Branch = "KTM", Notes = "Das ist ein cooles Bike", DateLastService = new DateTime(2016, 05, 27), RentalPriceFirstHour = 3.50, RentaulPriceAddHour = 5.00 };
            //Rentals r = new Rentals { Customer = c, bike = b, paid = false, RentalBegin = new DateTime(2018, 02, 14, 08, 15, 0), RentalEnd = new DateTime(2018, 02, 14, 10, 30, 0) };
            //Rentals r2 = new Rentals { Customer = c, bike = b, paid = false, RentalBegin = new DateTime(2017, 02, 14, 08, 15, 0), RentalEnd = new DateTime(2018, 02, 14, 10, 30, 0) };

            //rc.Bike.Add(b);
            //rc.Rental.Add(r);
            //rc.Rental.Add(r2);



            ////rc.Customer.Add(c);
            //rc.SaveChanges();
        }
        // GET api/customers
        [HttpGet]
        [Route("bikes")]
        public IActionResult Get([FromQuery] string lastName)
        {
            
            List<Bikes> filterBikes = new List<Bikes>();

            //for(int i=0; i<rc.Customer.Count(); i++)
            //{
            //    Customers c = new Customers();
            //    c = (Customers) rc.Customer.Where(f => f.Lastname == lastName);
            //    filterCust.Add(c);
            //}

            

            if (lastName != null)
            {
                return Ok(filterBikes);
            }
            else
            {
                return Ok(rc.Bike);
            }


            //for(int i=0; i<cust.Count; i++)
            //{
            //    if(cust[i].Lastname == lastName)
            //    {
            //        filterCust.Add(cust[i]);
            //    }
            //}

            //if(lastName != null)
            //{
            //    return Ok(filterCust);
            //}
            //else
            //{
            //    return Ok(cust);
            //}

        }


        // POST api/values
        [HttpPost]
        [Route("createBike")]
        public IActionResult Post([FromBody]Bikes bike)
        {
            rc.Bike.Add(bike);
            rc.SaveChanges();

            return Ok("Neues Rad hinzugefügt");
        }

        // PUT api/values/5
        [HttpPut]
        [Route("updateBike")]
        public IActionResult Put([FromQuery] int ID, [FromBody]Bikes bike)
        {

            if (ID != bike.ID)
            {
                return BadRequest();
            }

            rc.Entry(bike).State = Microsoft.EntityFrameworkCore.EntityState.Modified;

            rc.SaveChanges();

            return Ok("Das Update wurde vollzogen");

        }

        // DELETE api/values/5
        [HttpDelete]
        [Route("deleteBike")]
        public IActionResult Delete([FromQuery] int ID)
        {
            var bike = rc.Bike.SingleOrDefault(b => b.ID == ID);

            rc.Bike.Remove(bike);

            rc.SaveChanges();

            return Ok(bike);
        }
    }
}
